<?php require_once "includes/db.php";?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bem-vindo - HOME</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>
  <div class="container">
    <main style="padding: 21px;">
		<form action="cadastrar.php" method="get" style="border-top: 1px solid black; padding-top: 16px;">

		<br />
    	<br />
		<br />
		<h1 for="mensagem">É necessário informar todos os campos!</h1>
		<br />
		<br />
		<button class="btn btn-primary btn-lg">Voltar</button>
		</form>
	</main>
  </div>
</body>
</html>
